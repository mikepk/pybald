

CREATE TABLE IF NOT EXISTS `versions` (
    `version_id` mediumint(4) unsigned NOT NULL auto_increment,
    `subversion` mediumint(4) unsigned NOT NULL default 0,
    PRIMARY KEY (`version_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- MK v 0.0
-- Versions table
SET @max_version = (SELECT MAX(version_id) FROM versions);
UPDATE versions SET subversion = subversion + 1 WHERE version_id = @max_version; 


-- MK sessions table
DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
    `session_id` char(128) NOT NULL default '',
    `cache` varchar(8192) NOT NULL default '',
    `user_id` mediumint(4) unsigned NOT NULL default 0,
    `date_modified` timestamp NOT NULL default CURRENT_TIMESTAMP,
    PRIMARY KEY (`session_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- The users table
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
    `user_id` mediumint(4) unsigned NOT NULL auto_increment,
    `email` varchar(40) NOT NULL default '',
    `username` varchar(40) NOT NULL default '',
    `password` varchar(16) NOT NULL default '',
    `main_card_id` mediumint(4) unsigned NOT NULL default 0,
    `status` varchar(4) NOT NULL default 'OK',
    `date_created` timestamp NOT NULL default '0000-00-00 00:00:00',
    `date_modified` timestamp default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
    PRIMARY KEY (`user_id`),
    UNIQUE KEY `email` (`email`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
    

-- -- The partial registration table
-- -- this table represents users that gave us their email
-- -- but never completed the registration
-- DROP TABLE IF EXISTS `partial_registrations`;
-- CREATE TABLE `partial_registrations` (
--     `partial_registration_id` mediumint(4) unsigned NOT NULL auto_increment,
--     `email` varchar(40) NOT NULL default '',
--     `access_key` char(128) NOT NULL default '',
--     `date_created` timestamp NOT NULL default '0000-00-00 00:00:00',
--     PRIMARY KEY (`partial_registration_id`),
--     UNIQUE KEY `access_key` (`access_key`)
--     ) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `last_search_id`;
CREATE TABLE `last_search_id` (
    `last_search_id` bigint(4) unsigned NOT NULL default 0,
    PRIMARY KEY (`last_search_id`) 
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `twitter_ids`;
CREATE TABLE `twitter_ids` (
    `label` varchar(128) NOT NULL default '',
    `value` bigint(4) unsigned NOT NULL default 0,
    PRIMARY KEY (`label`) 
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `quote_searches`;
CREATE TABLE `quote_searches` (
    `search_id` mediumint(4) unsigned NOT NULL auto_increment,
    `search_term` varchar(80) NOT NULL default '',
    `last_search_hit_id` bigint(10) unsigned NOT NULL default 0,
    PRIMARY KEY (`search_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `quote_responses`;
CREATE TABLE `quote_responses` (
    `response_id` mediumint(4) unsigned NOT NULL auto_increment,
    `search_id` mediumint(4) unsigned NOT NULL,
    `movie_id` mediumint(4) unsigned NOT NULL,
    `response` varchar(140) NOT NULL,
    PRIMARY KEY (`response_id`),
    KEY `search_id` (`search_id`),
    KEY `movie_id` (`movie_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `movies`;
CREATE TABLE `movies` (
    `movie_id` mediumint(4) unsigned NOT NULL auto_increment,
    `movie_name` varchar(256) NOT NULL,
    `movie_link` varchar(1024) NOT NULL default '',
    PRIMARY KEY (`movie_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO movies (`movie_name`) VALUES ('2001: A Space Odyssey'),('Ghostbusters'),('The Princess Bride'),('Better Off Dead');


DROP TABLE IF EXISTS `search_hits`;
CREATE TABLE `search_hits` (
    `search_hit_id` mediumint(4) unsigned NOT NULL auto_increment,
    `search_id` mediumint(4) unsigned NOT NULL,
    `twitter_update_id` bigint(10) unsigned NOT NULL default 0,
    `twitter_update_text` varchar(140) NOT NULL default '',
    `twitter_user_id` int(10) unsigned NOT NULL default 0,
    `twitter_username` varchar(20) NOT NULL default '',
    `twitter_date` timestamp NOT NULL,
    PRIMARY KEY (`search_hit_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 
-- 
-- 
-- 
-- 
-- 
-- 
-- DROP TABLE IF EXISTS `addresses`;
-- CREATE TABLE `addresses` (
--     `address_id` mediumint(4) unsigned NOT NULL auto_increment,
--     `card_id` mediumint(4) unsigned NOT NULL default 0,
--     `pobox` varchar(10) NOT NULL default '',
--     `extadd` varchar(40) NOT NULL default '',
--     `street` varchar(40) NOT NULL default '',
--     `city` varchar(40) NOT NULL default '',
--     `state` varchar(40) NOT NULL default '',
--     `zip` varchar(40) NOT NULL default '',
--     `country` varchar(40) NOT NULL default '',
--     `type` varchar(40) NOT NULL default '',
--     PRIMARY KEY (`address_id`),
--     KEY `card_id` (`card_id`)
--     ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- 
-- DROP TABLE IF EXISTS `phones`;
-- CREATE TABLE `phones` (
--     `phone_id` mediumint(4) unsigned NOT NULL auto_increment,
--     `card_id` mediumint(4) unsigned NOT NULL default 0,
--     `number` varchar(30) NOT NULL default '',
--     `type` varchar(40) NOT NULL default '',
--     PRIMARY KEY (`phone_id`),
--     KEY `card_id` (`card_id`)
--     ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- 
-- DROP TABLE IF EXISTS `emails`;
-- CREATE TABLE `emails` (
--     `email_id` mediumint(4) unsigned NOT NULL auto_increment,
--     `card_id` mediumint(4) unsigned NOT NULL default 0,
--     `email` varchar(40) NOT NULL default '',
--     `type` varchar(40) NOT NULL default '',
--     PRIMARY KEY (`email_id`),
--     KEY `card_id` (`card_id`)
--     ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- 
-- DROP TABLE IF EXISTS `urls`;
-- CREATE TABLE `urls` (
--     `url_id` mediumint(4) unsigned NOT NULL auto_increment,
--     `card_id` mediumint(4) unsigned NOT NULL default 0,
--     `url` varchar(255) NOT NULL default '',
--     `label` varchar(40) NOT NULL default '',
--     PRIMARY KEY (`url_id`),
--     KEY `card_id` (`card_id`)
--     ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- 
-- 
-- -- Barcode processing queue
-- DROP TABLE IF EXISTS `barcode_image_queue`;
-- CREATE TABLE `barcode_image_queue` (
--     `image_id` mediumint(4) unsigned NOT NULL auto_increment,
--     `user_id` mediumint(4) unsigned NOT NULL default 0,
--     `from_email` varchar(40) NOT NULL default '',
--     `process_state` ENUM('unprocessed','decoded','easy_fail','hard_fail','contact_emailed','no_card','no_barcode') NOT NULL default 'unprocessed',
--     `decoded_text` char(128) NOT NULL default '',
--     `msg_text` varchar(8192) NOT NULL default '',
--     `filename` varchar(40) NOT NULL default '',
--     `original_filename` varchar(40) NOT NULL default '',
--     `date_created` timestamp NOT NULL default '0000-00-00 00:00:00',
--     `date_modified` timestamp default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
--     PRIMARY KEY (`image_id`)
--     ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
