#!/usr/bin/env python
# encoding: utf-8
"""
LastSearchId.py

Created by mikepk on 2010-03-07.
Copyright (c) 2010 Michael Kowalchik. All rights reserved.
"""

import sys
import os
import unittest

import app
from pybald.core.storage_engines.StoredObject import StoredObject

class LastSearchId(StoredObject):
    # These three class variables must be defined, they determine how the object
    # maps to the stored object
    table = "twitter_ids"
    key = "label"
    table_map = ['label','value']
    
    def __init__(self):
        StoredObject.__init__(self)
        self.label = 'last_search_id'
        self.value = None

    # def load():
    #     pass
    # 
    # def save():
    #     pass

class LastSearchIdTests(unittest.TestCase):
	def setUp(self):
		pass


if __name__ == '__main__':
	unittest.main()