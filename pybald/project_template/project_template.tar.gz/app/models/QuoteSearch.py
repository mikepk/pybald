#!/usr/bin/env python
# encoding: utf-8
"""
QuoteSearch.py

Created by mikepk on 2010-03-07.
Copyright (c) 2010 Michael Kowalchik. All rights reserved.
"""

import sys
import os
import unittest

import app
from pybald.core.storage_engines.StoredObject import StoredObject
# from pybald.core.storage_engines.Collection import Collection

class QuoteSearch(StoredObject):
    # These three class variables must be defined, they determine how the object
    # maps to the stored object
    table = "quote_searches"
    key = "search_id"
    table_map = ['search_id',
                'search_term',
                'last_search_hit_id']
    
    def __init__(self):
        StoredObject.__init__(self)
        self.search_id = None
        self.search_term = None
        self.last_search_hit_id = None



class QuoteSearchTests(unittest.TestCase):
	def setUp(self):
		pass


if __name__ == '__main__':
	unittest.main()