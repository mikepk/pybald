#!/usr/bin/env python
# encoding: utf-8
"""
ErrorController.py

Created by mikepk on 2009-07-25.
Copyright (c) 2009 Michael Kowalchik. All rights reserved.
"""

import sys
import os
import unittest
from pybald.core.BaseController import action, BaseController
from webob import Response
from mako import exceptions

import re

class ErrorController(BaseController):

    # map status codes to error controller actions
    error_map = {404:'not_found',
                 401:'not_authorized',
                 500:'index'}

    @action
    def __call__(self,req):
        self.page['title'] = "We've encountered an error."
        stack_trace = exceptions.html_error_template().render()
        # Having 'Mako' in the title could confuse people trying to debug
        # singe I'm using the mako stack trace for potentially any exception
        stack_trace = stack_trace.replace(r'<title>Mako Runtime Error</title>','<title>Runtime Error</title>')
        return Response(body=stack_trace, status=500)
        #return Response(body=self._view(), status=500)

    @action
    def index(self,req):
        self.page['title'] = "We've encountered an error."
        return Response(body=self._view(), status=500)

    @action
    def not_found(self,req):
        self.page['title'] = "Page not found."
        return Response(body=self._view(), status=404)

    @action
    def not_authorized(self,req):
        self.page['title'] = "You're not allowed to see this."
        return Response(body=self._view(), status=401)

class ErrorControllerTests(unittest.TestCase):
    def setUp(self):
        pass


if __name__ == '__main__':
    unittest.main()