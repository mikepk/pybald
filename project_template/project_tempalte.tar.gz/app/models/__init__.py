#!/usr/bin/env python
# encoding: utf-8
"""
__init__.py

Created by mikepk on 2009-07-26.
Copyright (c) 2009 Michael Kowalchik. All rights reserved.
"""


