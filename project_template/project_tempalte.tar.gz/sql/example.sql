

CREATE TABLE IF NOT EXISTS `versions` (
    `version_id` mediumint(4) unsigned NOT NULL auto_increment,
    `subversion` mediumint(4) unsigned NOT NULL default 0,
    PRIMARY KEY (`version_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- MK v 0.0
-- Versions table
SET @max_version = (SELECT MAX(version_id) FROM versions);
UPDATE versions SET subversion = subversion + 1 WHERE version_id = @max_version; 


-- MK sessions table
DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
    `session_id` char(128) NOT NULL default '',
    `cache` varchar(8192) NOT NULL default '',
    `user_id` mediumint(4) unsigned NOT NULL default 0,
    `date_modified` timestamp NOT NULL default CURRENT_TIMESTAMP,
    PRIMARY KEY (`session_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- The users table
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
    `user_id` mediumint(4) unsigned NOT NULL auto_increment,
    `email` varchar(40) NOT NULL default '',
    `username` varchar(40) NOT NULL default '',
    `password` varchar(16) NOT NULL default '',
    `main_card_id` mediumint(4) unsigned NOT NULL default 0,
    `status` varchar(4) NOT NULL default 'OK',
    `date_created` timestamp NOT NULL default '0000-00-00 00:00:00',
    `date_modified` timestamp default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
    PRIMARY KEY (`user_id`),
    UNIQUE KEY `email` (`email`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
    

-- The partial registration table
-- this table represents users that gave us their email
-- but never completed the registration
DROP TABLE IF EXISTS `partial_registrations`;
CREATE TABLE `partial_registrations` (
    `partial_registration_id` mediumint(4) unsigned NOT NULL auto_increment,
    `email` varchar(40) NOT NULL default '',
    `access_key` char(128) NOT NULL default '',
    `date_created` timestamp NOT NULL default '0000-00-00 00:00:00',
    PRIMARY KEY (`partial_registration_id`),
    UNIQUE KEY `access_key` (`access_key`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `cards`;
CREATE TABLE `cards` (
    `card_id` mediumint(4) unsigned NOT NULL auto_increment,
    `card_key` char(128) NOT NULL default '', 
    `user_id`  mediumint(4) unsigned NOT NULL default 0,
    `card_type` varchar(40) NOT NULL default 'main',
    `full_name` varchar(40) NOT NULL default '',
    `last_name` varchar(40) NOT NULL default '',
    `first_name` varchar(40) NOT NULL default '',
    `additional` varchar(40) NOT NULL default '',
    `prefix` varchar(10) NOT NULL default '',
    `suffix` varchar(10) NOT NULL default '',
    `company` varchar(40) NOT NULL default '',
    `title` varchar(40) NOT NULL default '',
    PRIMARY KEY (`card_id`), 
-- each card id has a barcode assoc. with it
    UNIQUE KEY `card_key` (`card_key`),
    KEY `user_id` (`user_id`)    
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `photos`;
CREATE TABLE `photos` (
    `photo_id` mediumint(4) unsigned NOT NULL auto_increment,
    `card_id` mediumint(4) unsigned NOT NULL default 0,
    `photo_url` varchar(80) NOT NULL default '',
    `thumb_url` varchar(80) NOT NULL default '',
    -- -- BASE64 text encoded version for vcards, should probably be _text table
    -- `photo_text` varchar(4096) NOT NULL default '',
    PRIMARY KEY (`photo_id`),
    KEY `card_id` (`card_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Consolidate with cards for now
-- DROP TABLE IF EXISTS `names`;
-- CREATE TABLE `names` (
--     `name_id` mediumint(4) unsigned NOT NULL auto_increment,
--     `last_name` varchar(40) NOT NULL default '',
--     `first_name` varchar(40) NOT NULL default '',
--     `additional` varchar(40) NOT NULL default '',
--     `prefix` varchar(10) NOT NULL default '',
--     `suffix` varchar(10) NOT NULL default '',
-- ) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `addresses`;
CREATE TABLE `addresses` (
    `address_id` mediumint(4) unsigned NOT NULL auto_increment,
    `card_id` mediumint(4) unsigned NOT NULL default 0,
    `pobox` varchar(10) NOT NULL default '',
    `extadd` varchar(40) NOT NULL default '',
    `street` varchar(40) NOT NULL default '',
    `city` varchar(40) NOT NULL default '',
    `state` varchar(40) NOT NULL default '',
    `zip` varchar(40) NOT NULL default '',
    `country` varchar(40) NOT NULL default '',
    `type` varchar(40) NOT NULL default '',
    PRIMARY KEY (`address_id`),
    KEY `card_id` (`card_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `phones`;
CREATE TABLE `phones` (
    `phone_id` mediumint(4) unsigned NOT NULL auto_increment,
    `card_id` mediumint(4) unsigned NOT NULL default 0,
    `number` varchar(30) NOT NULL default '',
    `type` varchar(40) NOT NULL default '',
    PRIMARY KEY (`phone_id`),
    KEY `card_id` (`card_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `emails`;
CREATE TABLE `emails` (
    `email_id` mediumint(4) unsigned NOT NULL auto_increment,
    `card_id` mediumint(4) unsigned NOT NULL default 0,
    `email` varchar(40) NOT NULL default '',
    `type` varchar(40) NOT NULL default '',
    PRIMARY KEY (`email_id`),
    KEY `card_id` (`card_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `urls`;
CREATE TABLE `urls` (
    `url_id` mediumint(4) unsigned NOT NULL auto_increment,
    `card_id` mediumint(4) unsigned NOT NULL default 0,
    `url` varchar(255) NOT NULL default '',
    `label` varchar(40) NOT NULL default '',
    PRIMARY KEY (`url_id`),
    KEY `card_id` (`card_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- Barcode processing queue
DROP TABLE IF EXISTS `barcode_image_queue`;
CREATE TABLE `barcode_image_queue` (
    `image_id` mediumint(4) unsigned NOT NULL auto_increment,
    `user_id` mediumint(4) unsigned NOT NULL default 0,
    `from_email` varchar(40) NOT NULL default '',
    `process_state` ENUM('unprocessed','decoded','easy_fail','hard_fail','contact_emailed','no_card','no_barcode') NOT NULL default 'unprocessed',
    `decoded_text` char(128) NOT NULL default '',
    `msg_text` varchar(8192) NOT NULL default '',
    `filename` varchar(40) NOT NULL default '',
    `original_filename` varchar(40) NOT NULL default '',
    `date_created` timestamp NOT NULL default '0000-00-00 00:00:00',
    `date_modified` timestamp default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
    PRIMARY KEY (`image_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `temporary_cards`;
-- CREATE TABLE `temporary_cards` (
--     `card_id` mediumint(4) unsigned NOT NULL auto_increment,
--     `card_key` char(128) NOT NULL default '', 
--     `user_id`  mediumint(4) unsigned NOT NULL default 0,
--     `card_type` varchar(40) NOT NULL default 'main',
--     `full_name` varchar(40) NOT NULL default '',
--     `last_name` varchar(40) NOT NULL default '',
--     `first_name` varchar(40) NOT NULL default '',
--     `additional` varchar(40) NOT NULL default '',
--     `prefix` varchar(10) NOT NULL default '',
--     `suffix` varchar(10) NOT NULL default '',
--     `company` varchar(40) NOT NULL default '',
--     `title` varchar(40) NOT NULL default '',
--     PRIMARY KEY (`card_id`), 
-- -- each card id has a barcode assoc. with it
--     UNIQUE KEY `card_key` (`card_key`),
--     KEY `user_id` (`user_id`)    
--     ) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Stop obsessing, flip to a params table to add whatever I want
-- This should get broken out later, more than likely
DROP TABLE IF EXISTS `cards_params`;
-- CREATE TABLE `cards_params` (
--     `card_id`  mediumint(4) unsigned NOT NULL default 0,
--     `type` varchar(40) NOT NULL default '',
--     `attributes` varchar(256) NOT NULL default '',
--     `value`  varchar(1024) NOT NULL default '',
--     KEY `card_id` (`card_id`),
--     KEY `type` (`type`)
--     ) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `scratch_pad`;
-- CREATE TABLE `scratch_pad` (
--     `scratch_pad_id` mediumint(4) unsigned NOT NULL auto_increment,
--     `data` varchar(10240) NOT NULL default '',
--     KEY `scratch_pad_id` (`scratch_pad_id`)
--     ) ENGINE=InnoDB DEFAULT CHARSET=utf8;